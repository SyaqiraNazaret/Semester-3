<?php
$serverName = "localhost"; // Ganti dengan nama server SQL Server
$connectionOptions = [
    "Database" => "Prestasi_Mahasiswa", // Ganti dengan nama database
    "Uid" => "Username",          // Ganti dengan username SQL Server
    "PWD" => "Password"           // Ganti dengan password SQL Server
];

$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>
